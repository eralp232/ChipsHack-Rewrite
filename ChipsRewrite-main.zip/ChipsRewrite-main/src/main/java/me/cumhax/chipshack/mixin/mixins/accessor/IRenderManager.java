package me.cumhax.chipshack.mixin.mixins.accessor;

public interface IRenderManager 
{
	double getRenderPosX();

	double getRenderPosY();

	double getRenderPosZ();
}