package me.cumhax.chipshack.setting;

public enum SettingType
{
	BOOLEAN,
	INTEGER,
	ENUM
}
