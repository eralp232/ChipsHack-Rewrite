package me.cumhax.chipshack.module.hud;

import me.cumhax.chipshack.module.Category;
import me.cumhax.chipshack.module.Module;

public class CustomFont extends Module
{
		public CustomFont() {
        super("CustomFont", "", Category.HUD);
    }
	public CustomFont(String name, String description, Category category)
	{
		super(name, description, category);
	}
}
