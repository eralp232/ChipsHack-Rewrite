package me.cumhax.chipshack.util;

public class FriendUtil
{
    private final String name;

    public FriendUtil(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
}