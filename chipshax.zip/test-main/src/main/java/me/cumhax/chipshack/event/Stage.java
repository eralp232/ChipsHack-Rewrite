package me.cumhax.chipshack.event;

public enum Stage {

    PRE,
    POST

}
