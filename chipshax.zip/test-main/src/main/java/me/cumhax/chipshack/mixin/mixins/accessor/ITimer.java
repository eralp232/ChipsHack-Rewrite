package me.cumhax.chipshack.mixin.mixins.accessor;

public interface ITimer
{
	float getTickLength();
	void setTickLength(float length);
}
